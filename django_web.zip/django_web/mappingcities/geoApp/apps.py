from django.apps import AppConfig


class GeoappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'geoApp'
