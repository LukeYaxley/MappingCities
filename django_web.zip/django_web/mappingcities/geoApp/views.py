from django.shortcuts import render, redirect
import os
import folium
import geopandas as gpd
import pandas as pd
import overpy
import matplotlib.pyplot as plt
api = overpy.Overpass()

# Create your views here.
def fullMap(request):
    shp_dir = os.path.join(os.getcwd(), 'media')
    m = folium.Map(location=[54.38, -2.7], zoom_start=6.99)

    england = gpd.read_file(os.path.join(shp_dir, 'Major_Road_Network_2018_Open_Roads.shp'))
    scotland = gpd.read_file(os.path.join(shp_dir, 'roads.shp'))
    test = scotland.get(scotland['type'] == 'primary')
    test2 = england.head(10)
    folium.GeoJson(data=test2['geometry']).add_to(m)
    folium.GeoJson(data=test['geometry']).add_to(m)

    folium.LayerControl().add_to(m)
    m = m._repr_html_()
    context = {'my_map': m}
    return render(request, 'geoApp/fullMap.html', context)


def home(request):
    return render(request, 'geoApp/home.html')

def dimensional(request):
    shp_dir = os.path.join(os.getcwd(), 'media')
    shp = gpd.read_file(os.path.join(shp_dir, 'roads.shp'))
    # To extract the only required road networks to display
    test = shp.get(shp['type'] == 'primary')
    test2 = shp.get(shp['type'] == 'motorway')
    test3 = shp.get(shp['type'] == 'minor')

    merged = gpd.GeoDataFrame(pd.concat([test, test2, test3]))
    mapped = merged.plot()
    mapped = plt.savefig('static/mapped.jpg')

    return render(request, 'geoApp/dimensional.html')

def get_roads(city_name):
# function to fetch all ways and nodes
    try:
        result = api.query(f"""
            [timeout:60][out:json];
        area[name ="{city_name}"];
        (
        way(area)
        ['name']
        ['highway']
        ['highway' !~ 'path']
        ['highway' !~ 'steps']
        ['highway' !~ 'motorway']
        ['highway' !~ 'motorway_link']
        ['highway' !~ 'raceway']
        ['highway' !~ 'bridleway']
        ['highway' !~ 'proposed']
        ['highway' !~ 'construction']
        ['highway' !~ 'elevator']
        ['highway' !~ 'bus_guideway']
        ['highway' !~ 'footway']
        ['highway' !~ 'cycleway']
        ['foot' !~ 'no']
        ['access' !~ 'private']
        ['access' !~ 'no'];
        );
        (._;>;);
        out body;
                """)
        return result.ways
    except overpy.exception.OverpassTooManyRequests:
        print("City has too many nodes for city to handle")
    finally:
        return None
